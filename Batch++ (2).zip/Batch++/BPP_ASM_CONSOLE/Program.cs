﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace BPP_ASM_CONSOLE
{
    class Program
    {
        static void Main(string[] args)
        {
            string toCompile = "";

            int counter = 0;
            string line;

            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(args[0]);
            while ((line = file.ReadLine()) != null)
            {
                toCompile += ToASM(line);
            }

            string code = toCompile;

            counter++;

            file.Close();

            string FinishedProduct = " ;Starting SHIT " + Environment.NewLine +

".386 " + Environment.NewLine +
 ".model flat, stdcall " + Environment.NewLine +
 "option casemap: none " + Environment.NewLine +
 "include \\masm32\\include\\windows.inc " + Environment.NewLine +
 "include \\masm32\\include\\kernel32.inc " + Environment.NewLine +
 "include \\masm32\\include\\masm32.inc " + Environment.NewLine +
 "include \\masm32\\include\\user32.inc " + Environment.NewLine +

 "includelib \\masm32\\lib\\kernel32.lib " + Environment.NewLine +
 "includelib \\masm32\\lib\\masm32.lib " + Environment.NewLine +


 "; VARIABLES " + Environment.NewLine + Environment.NewLine +

  ".const " + Environment.NewLine +
  Const_vars + Environment.NewLine + Environment.NewLine +

  ".data " + Environment.NewLine +
  vars + Environment.NewLine + Environment.NewLine + Environment.NewLine +




 "; THE ACTUAL CODE " + Environment.NewLine +
 ".code " + Environment.NewLine +
 code + Environment.NewLine;



            Console.WriteLine(FinishedProduct);
            Compile(args[1], FinishedProduct);

        }

        static string vars = " ";
        static string Const_vars = " ";
        static string vars_2 = " ";
        static List<string> vars_list = new List<string>();

        public readonly static Random rand = new Random();

        static string ToASM(string line)
        {
            string Finished_Item = " ";
              
            string[] args_ = (line).Trim().Split(' ');

            if (args_[0] == "echo")
            {
                foreach(string s in vars_list)
                {
                    if (s == args_[1])
                    {
                        string toSay2 = "";
                        int counter2_ = 0;
                        foreach (string arg in args_)
                        {
                            if (counter2_ > 0)
                            {
                                toSay2 += arg + " ";
                            }
                            counter2_++;
                        }
                        return "invoke StdOut, addr " + toSay2 + Environment.NewLine;
                    } 
                }

                string var_name = "BPP_CONST_VARIABLE_" + rand.Next(100000, 999999).ToString();

                string toSay = "";
                string toSay3 = "";
                int counter3_ = 0;


                foreach (string arg in args_)
                {
                    if (counter3_ > 0)
                    {
                        toSay3 += arg + " ";
                    }
                    counter3_++;
                }
                SetStringConst(var_name, toSay3);

                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "invoke StdOut, addr " + var_name + Environment.NewLine;



            }
            if (args_[0] == "input")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "invoke StdIn, addr " + toSay + ", sizeof " + toSay + Environment.NewLine;
            }
            if (args_[0] == "set")
            {
                int toTry;


                if (args_[2] != string.Empty)
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    SetString(args_[1], toSay);
                }
                else if (int.TryParse(args_[2], out toTry))
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    vars += "" + args_[1] + " dw \"" + toSay + "\", 0" + Environment.NewLine;
                    vars_list.Add(vars);
                }

            }
            if (args_[0].StartsWith(":")) 
            {
                return args_[0].TrimStart(':') + ":" + Environment.NewLine;
            }
            if (args_[0] == "goto")
            {
                return "jmp " + args_[1] + Environment.NewLine;
            }
            if (args_[0] == "end")
            {
                return "end " + args_[1] + Environment.NewLine;
            }
            if (args_[0] == "exit")
            {
                return "invoke ExitProcess, 0" + Environment.NewLine;
            }
            if (args_[0] == "msgbox")
            {
                int max_num = rand.Next(500000, 999999);
                int min_num = rand.Next(100000, 500000);
                int num = rand.Next(min_num, max_num);
                foreach (string s in vars_list)
                {
                    if (s == args_[1])
                    {
                        string toSay2 = "";
                        int counter2_ = 0;
                        foreach (string arg in args_)
                        {
                            if (counter2_ > 0)
                            {
                                toSay2 += arg + " ";
                            }
                            counter2_++;
                        }
                        return "invoke MessageBox, 0, addr " + toSay2 + ",NULL,MB_OK" + Environment.NewLine;
                    }
                }

                bool isCheck = true;
                string var_name = "";
                while (isCheck)
                {
                    top:
                    var_name = "BPP_CONST_VARIABLE_" + num.ToString();

                    foreach (string sz in vars_list)
                    {
                        if (sz == var_name)
                        {
                            goto top;
                        }
                    }

                    isCheck = false;
                }


                string toSay3 = "";
                int counter3_ = 0;


                foreach (string arg in args_)
                {
                    if (counter3_ > 0)
                    {
                        toSay3 += arg + " ";
                    }
                    counter3_++;
                }
                Const_vars += var_name + " db \"" + toSay3 + "\", 0" + Environment.NewLine;

                return "invoke MessageBox, 0, addr " + var_name + ",NULL,MB_OK" + Environment.NewLine;
            }
            if (args_[0] == "if" || args_[0] == "else" || args_[0] == "elseif" || args_[0] == "endif" || args_[0] == "while" || args_[0] == "repeat" || args_[0] == "until")
            {
                string together = "";
                foreach (string arg in args_)
                {
                   together += arg + " ";
                }

                together = "." + together + Environment.NewLine;
                return together;
            }










                return Finished_Item;
        }



        static void Compile(string fileName, string toCompile)
        {
            File.WriteAllText(fileName, toCompile);
        }

        static void SetString(string varName, string str)
        {

            vars += "" + varName + " db \"" + str + "\", 0" + Environment.NewLine;
            vars_list.Add(varName);
        }

        static void SetStringConst(string varName, string str)
        {
            Const_vars += "" + varName + " db \"" + str + "\", 0" + Environment.NewLine;
            vars_list.Add(varName);
        }
    }
}
