﻿using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.IO;
using System.Net.Mail;
using System.Security.Cryptography;

namespace Batch__
{
    class Program
    {
 
        static void Main(string[] args)
        {
            string key = "KEY" + random.Next(10000, 99999).ToString();
            EncryptionKey = key;
            Form f = new Form();
            string toCompile = "";

            int counter = 0;
            string line;

            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(args[0]);
            while ((line = file.ReadLine()) != null)
            {
                toCompile += ToCSharp(ReplaceItems(line));
            }


            counter++;

            file.Close();

            string SomeThingsToAdd_using = " " + Environment.NewLine;
            string SomeThingsToAdd_inside = " " + Environment.NewLine;
            string Other_Classes = " " + Environment.NewLine;
            string compilerOptions = " ";

            if (usingVolume)
            {
                SomeThingsToAdd_inside += "private const int APPCOMMAND_VOLUME_MUTE = 0x80000;" + Environment.NewLine +
        " private const int APPCOMMAND_VOLUME_UP = 0xA0000;" + Environment.NewLine +
        "private const int APPCOMMAND_VOLUME_DOWN = 0x90000;" + Environment.NewLine +
        "private const int WM_APPCOMMAND = 0x319;" + Environment.NewLine +

        "[DllImport(\"user32.dll\")]" + Environment.NewLine +
        "public static extern IntPtr SendMessageW(IntPtr hWnd, int Msg," + Environment.NewLine +
          "  IntPtr wParam, IntPtr lParam);" + Environment.NewLine;
    }

            if (usingGraphics)
            {
            }

            if (usingRecEngine)
            {
                SomeThingsToAdd_using += "using System.Speech.Recognition;";
                SomeThingsToAdd_inside += "static SpeechRecognitionEngine speechRecognitionEngine = new SpeechRecognitionEngine();";
            }

            if (usingVoids)
            {
                SomeThingsToAdd_using += "using System.Speech.Synthesis; ";
                SomeThingsToAdd_inside += "static SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();";
            }

            if (usingKeys)
            {
                Other_Classes += "public class GlobalKeyboardHook {[DllImport(\"user32.dll\")] static extern int CallNextHookEx(IntPtr hhk, int code, int wParam, ref keyBoardHookStruct lParam);[DllImport(\"user32.dll\")] static extern IntPtr SetWindowsHookEx(int idHook, LLKeyboardHook callback, IntPtr hInstance, uint theardID);[DllImport(\"user32.dll\")] static extern bool UnhookWindowsHookEx(IntPtr hInstance);[DllImport(\"kernel32.dll\")] static extern IntPtr LoadLibrary(string lpFileName); public delegate int LLKeyboardHook(int Code, int wParam, ref keyBoardHookStruct lParam); public struct keyBoardHookStruct { public int vkCode; public int scanCode; public int flags; public int time; public int dwExtraInfo; } const int WH_KEYBOARD_LL = 13; const int WM_KEYDOWN = 0x0100; const int WM_KEYUP = 0x0101; const int WM_SYSKEYDOWN = 0x0104; const int WM_SYSKEYUP = 0x0105; LLKeyboardHook llkh; public List<Keys> HookedKeys = new List<Keys>(); IntPtr Hook = IntPtr.Zero; public event KeyEventHandler KeyDown; public event KeyEventHandler KeyUp; public GlobalKeyboardHook() { llkh = new LLKeyboardHook(HookProc); } ~GlobalKeyboardHook() { unhook(); } public void hook() { IntPtr hInstance = LoadLibrary(\"User32\"); Hook = SetWindowsHookEx(WH_KEYBOARD_LL, llkh, hInstance, 0); } public void unhook() { UnhookWindowsHookEx(Hook); } public int HookProc(int Code, int wParam, ref keyBoardHookStruct lParam) { if (Code >= 0) { Keys key = (Keys)lParam.vkCode; if (HookedKeys.Contains(key)) { KeyEventArgs kArg = new KeyEventArgs(key); if ((wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) && (KeyDown != null)) KeyDown(this, kArg); else if ((wParam == WM_KEYUP || wParam == WM_SYSKEYUP) && (KeyUp != null)) KeyUp(this, kArg); if (kArg.Handled) return 1; } } return CallNextHookEx(Hook, Code, wParam, ref lParam); } }" + Environment.NewLine;
                SomeThingsToAdd_inside += "static GlobalKeyboardHook gHook;";
            }

            if (usingImap)
            {
                SomeThingsToAdd_using += "using S22.Imap;";
            }
            if (usingColor)
            {
                SomeThingsToAdd_inside += Environment.NewLine + "[DllImport(\"kernel32.dll\", SetLastError=true)]" + Environment.NewLine +
                "public static extern bool SetConsoleTextAttribute( IntPtr hConsoleOutput,Int32 wAttributes);" + Environment.NewLine +
                "[DllImport(\"kernel32.dll\")]" + Environment.NewLine +
                "public static extern IntPtr GetStdHandle(int nStdHandle); " + Environment.NewLine;
            }

            if (usingWindow)
            {
                SomeThingsToAdd_inside += Environment.NewLine + "  [DllImport(\"user32.dll\")] " + Environment.NewLine +
                "static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);" + Environment.NewLine +

                " [DllImport(\"user32.dll\", SetLastError = true)]" + Environment.NewLine +
                "static extern int GetWindowLong(IntPtr hWnd, int nIndex);" + Environment.NewLine +

                "[DllImport(\"user32.dll\", SetLastError = true)]" + Environment.NewLine +
                "static extern IntPtr FindWindow(string lpClassName, string lpWindowName);" + Environment.NewLine +

                "[DllImport(\"user32.dll\")]" + Environment.NewLine +
       " [return: MarshalAs(UnmanagedType.Bool)]" + Environment.NewLine +
       " public static extern bool GetWindowRect(IntPtr hwnd, out RECT lpRect);" + Environment.NewLine +

       " public struct RECT" + Environment.NewLine +
        "{" + Environment.NewLine +
           " public int left, top, right, bottom;" + Environment.NewLine +
       " } " + Environment.NewLine;
    }

            if (usingCoord)
            {
                SomeThingsToAdd_inside += " [StructLayout(LayoutKind.Sequential)]" + Environment.NewLine +
        " internal struct COORD" + Environment.NewLine +
        " {" + Environment.NewLine +
            " internal short X;" + Environment.NewLine +
            " internal short Y;" + Environment.NewLine +

           "  internal COORD(short x, short y)" + Environment.NewLine +
            " {" + Environment.NewLine +
               "  X = x;" + Environment.NewLine +
               "  Y = y;" + Environment.NewLine +
            " }" + Environment.NewLine +
        " }" + Environment.NewLine;
    }

            if (usingConsoleFont)
            {
                SomeThingsToAdd_inside += " private const int STD_OUTPUT_HANDLE = -11;" + Environment.NewLine +
                " private const int TMPF_TRUETYPE = 4;" + Environment.NewLine +
                " private const int LF_FACESIZE = 32;" + Environment.NewLine +
                " private static IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);" + Environment.NewLine +
                " public const ushort FW_NORMAL = 400;" + Environment.NewLine +


                "   [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]" + Environment.NewLine +
                " internal unsafe struct CONSOLE_FONT_INFO_EX" + Environment.NewLine +
                "  {" + Environment.NewLine +
                "   internal uint cbSize;" + Environment.NewLine +
                " internal uint nFont;" + Environment.NewLine +
                " internal COORD dwFontSize;" + Environment.NewLine +
                " internal int FontFamily;" + Environment.NewLine +
                " internal int FontWeight;" + Environment.NewLine +
                "  internal fixed char FaceName[LF_FACESIZE];" + Environment.NewLine +
                " }" + Environment.NewLine +

                "  [DllImport(\"kernel32.dll\", SetLastError = true)]" + Environment.NewLine +
                "  static extern bool SetCurrentConsoleFontEx(" + Environment.NewLine +
                " IntPtr consoleOutput," + Environment.NewLine +
                "  bool maximumWindow," + Environment.NewLine +
                "  ref CONSOLE_FONT_INFO_EX consoleCurrentFontEx);" + Environment.NewLine +


                " [DllImport(\"kernel32.dll\", SetLastError = true)]" + Environment.NewLine +
                " static extern int SetConsoleFont(" + Environment.NewLine +
                " IntPtr hOut," + Environment.NewLine +
                " uint dwFontNum" + Environment.NewLine +
                " );" + Environment.NewLine +
                " public static void SetConsoleFont(string fontName = \"Lucida Console\", short fontSize = 12)" + Environment.NewLine +
                " {" + Environment.NewLine +
                " unsafe" + Environment.NewLine +
                " {" + Environment.NewLine +
                " IntPtr hnd = GetStdHandle(STD_OUTPUT_HANDLE);" + Environment.NewLine +
                " CONSOLE_FONT_INFO_EX info = new CONSOLE_FONT_INFO_EX();" + Environment.NewLine +
                " info.cbSize = (uint)Marshal.SizeOf(info);" + Environment.NewLine +
                " CONSOLE_FONT_INFO_EX newInfo = new CONSOLE_FONT_INFO_EX();" + Environment.NewLine +
                " newInfo.cbSize = (uint)Marshal.SizeOf(newInfo);" + Environment.NewLine +
                " IntPtr ptr = new IntPtr(newInfo.FaceName);" + Environment.NewLine +
                " Marshal.Copy(fontName.ToCharArray(), 0, ptr, fontName.Length);" + Environment.NewLine +
                " newInfo.dwFontSize = new COORD(fontSize, fontSize);" + Environment.NewLine +
                " newInfo.FontWeight = FW_NORMAL;" + Environment.NewLine +
                " SetCurrentConsoleFontEx(hnd, false, ref newInfo);" + Environment.NewLine +
                " }" + Environment.NewLine +
                " }" + Environment.NewLine;

                if (!compilerOptions.Contains(@"/unsafe"))
                {
                    compilerOptions += @"/unsafe";
                }

                if (!usingColor)
                {
                    SomeThingsToAdd_inside += "  [DllImport(\"kernel32.dll\", SetLastError = true)]" + Environment.NewLine +
"  public static extern bool SetConsoleTextAttribute(IntPtr hConsoleOutput, Int32 wAttributes);" + Environment.NewLine;
                }

                Console.WriteLine("USING FONT CONSOLE = TRUE!");
            }

            if (usingCryto)
            {
                SomeThingsToAdd_using += "using System.Security.Cryptography;";
                SomeThingsToAdd_inside += "public static string Encrypt(string clearText, string key_)" + Environment.NewLine +
        "{" + Environment.NewLine +
            "byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);" + Environment.NewLine +
            "using (Aes encryptor = Aes.Create())" + Environment.NewLine +
            "{" + Environment.NewLine +
                "byte[] IV = new byte[15];" + Environment.NewLine +
                "rand.NextBytes(IV);" + Environment.NewLine +
                "Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(key_, IV);" + Environment.NewLine +
                "encryptor.Key = pdb.GetBytes(32);" + Environment.NewLine +
                "encryptor.IV = pdb.GetBytes(16);" + Environment.NewLine +
                "using (MemoryStream ms = new MemoryStream())" + Environment.NewLine +
                "{" + Environment.NewLine +
                    "using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))" + Environment.NewLine +
                    "{" + Environment.NewLine +
                        "cs.Write(clearBytes, 0, clearBytes.Length);" + Environment.NewLine +
                        "cs.Close();" + Environment.NewLine +
                    "}" + Environment.NewLine +
                    "clearText = Convert.ToBase64String(IV) + Convert.ToBase64String(ms.ToArray());" + Environment.NewLine +
                "}" + Environment.NewLine +
            "}" + Environment.NewLine +
            "return clearText;" + Environment.NewLine +
        "}" + Environment.NewLine +

        "public static string Decrypt(string cipherText, string key_)" + Environment.NewLine +
        "{" + Environment.NewLine +
            "byte[] IV = Convert.FromBase64String(cipherText.Substring(0, 20));" + Environment.NewLine +
            "cipherText = cipherText.Substring(20).Replace(\" \", \"+\");" + Environment.NewLine +
            "byte[] cipherBytes = Convert.FromBase64String(cipherText);" + Environment.NewLine +
            "using (Aes encryptor = Aes.Create())" + Environment.NewLine +
            "{" + Environment.NewLine +
                "Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(key_, IV);" + Environment.NewLine +
                "encryptor.Key = pdb.GetBytes(32);" + Environment.NewLine +
                "encryptor.IV = pdb.GetBytes(16);" + Environment.NewLine +
                "using (MemoryStream ms = new MemoryStream())" + Environment.NewLine +
                "{" + Environment.NewLine +
                    "using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))" + Environment.NewLine +
                    "{" + Environment.NewLine +
                        "cs.Write(cipherBytes, 0, cipherBytes.Length);" + Environment.NewLine +
                        "cs.Close();" + Environment.NewLine +
                    "}" + Environment.NewLine +
                    "cipherText = Encoding.Unicode.GetString(ms.ToArray());" + Environment.NewLine +
                "}" + Environment.NewLine +
            "}" + Environment.NewLine +
           " return cipherText;" + Environment.NewLine +
        "}" + Environment.NewLine;
            }



            if (usingBPPS)
            {
                SomeThingsToAdd_using += "using System.Security.Cryptography;";

                SomeThingsToAdd_inside += "public static string EncryptionKey = \"" + EncryptionKey + "\";" + Environment.NewLine +

        "public static string EncryptBPPS(string clearText)" + Environment.NewLine +
        "{" + Environment.NewLine +
            "byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);" + Environment.NewLine +
            "using (Aes encryptor = Aes.Create())" + Environment.NewLine +
            "{" + Environment.NewLine +
                "byte[] IV = new byte[15];" + Environment.NewLine +
                "rand.NextBytes(IV);" + Environment.NewLine +
                "Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, IV);" + Environment.NewLine +
                "encryptor.Key = pdb.GetBytes(32);" + Environment.NewLine +
                "encryptor.IV = pdb.GetBytes(16);" + Environment.NewLine +
                "using (MemoryStream ms = new MemoryStream())" + Environment.NewLine +
                "{" + Environment.NewLine +
                    "using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))" + Environment.NewLine +
                    "{" + Environment.NewLine +
                        "cs.Write(clearBytes, 0, clearBytes.Length);" + Environment.NewLine +
                        "cs.Close();" + Environment.NewLine +
                    "}" + Environment.NewLine +
                    "clearText = Convert.ToBase64String(IV) + Convert.ToBase64String(ms.ToArray());" + Environment.NewLine +
                "}" + Environment.NewLine +
            "}" + Environment.NewLine +
            "return clearText;" + Environment.NewLine +
        "}" + Environment.NewLine +

        "public static string DecryptBPPS(string cipherText)" + Environment.NewLine +
        "{" + Environment.NewLine +
            "byte[] IV = Convert.FromBase64String(cipherText.Substring(0, 20));" + Environment.NewLine +
            "cipherText = cipherText.Substring(20).Replace(\" \", \"+\");" + Environment.NewLine +
            "byte[] cipherBytes = Convert.FromBase64String(cipherText);" + Environment.NewLine +
            "using (Aes encryptor = Aes.Create())" + Environment.NewLine +
            "{" + Environment.NewLine +
                "Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, IV);" + Environment.NewLine +
                "encryptor.Key = pdb.GetBytes(32);" + Environment.NewLine +
                "encryptor.IV = pdb.GetBytes(16);" + Environment.NewLine +
                "using (MemoryStream ms = new MemoryStream())" + Environment.NewLine +
                "{" + Environment.NewLine +
                    "using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))" + Environment.NewLine +
                    "{" + Environment.NewLine +
                        "cs.Write(cipherBytes, 0, cipherBytes.Length);" + Environment.NewLine +
                        "cs.Close();" + Environment.NewLine +
                    "}" + Environment.NewLine +
                    "cipherText = Encoding.Unicode.GetString(ms.ToArray());" + Environment.NewLine +
                "}" + Environment.NewLine +
            "}" + Environment.NewLine +
           " return cipherText;" + Environment.NewLine +
        "}" + Environment.NewLine;
            }



            string FinishedProduct = " ";
            if (usingVoids)
            {
                FinishedProduct = "" + SomeThingsToAdd_using + "using System.Text; using System.IO; using System.Net.Mail; using System.Collections.Generic; using System.Threading.Tasks; using System; using System.Windows.Forms; using System.Diagnostics;  using System.Runtime.InteropServices; using System.Drawing; using Microsoft.Win32; using System.Threading;" +
                    " class Program {  " + SomeThingsToAdd_inside + " static Point pt = new Point(); static Random rand = new Random();" + dllImports + " " + toCompile + " } " + Other_Classes;
            }
            else
            {
                FinishedProduct = "" + SomeThingsToAdd_using + "using System.Text; using System.IO; using System.Net.Mail; using System.Collections.Generic; using System.Threading.Tasks; using System; using System.Windows.Forms; using System.Diagnostics;  using System.Runtime.InteropServices; using System.Drawing; using Microsoft.Win32; using System.Threading;" +
                    " class Program {  " + SomeThingsToAdd_inside + "  static Point pt = new Point();static Random rand = new Random();" + dllImports + " static void Main(string[] args) { " + toCompile + " } } "+ Other_Classes;
            }


            Console.WriteLine(FinishedProduct);
            Compile(args[1], FinishedProduct, compilerOptions);

        }

        static Random random = new Random();

        static string ToCSharp(string line)
        {
            string[] args_ = (line).Trim().Split(' ');

            if (args_[0] == "echo" || args_[0] == "print" || args_[0] == "say")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.WriteLine(" + toSay + ");" + Environment.NewLine;
            }
            else if (args_[0] == "echo_nl")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.Write(" + toSay + ");" + Environment.NewLine;
            }
            else if (args_[0] == "pause")
            {
                if (args_[1] == string.Empty)
                {
                    return "Console.ReadKey()" + Environment.NewLine;
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Console.Write(" + toSay + "); Console.ReadKey();";
                }

            }
            else if (args_[0] == "set")
            {
                if (args_[1] == "/p")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Console.Write(" + toSay + ");" + "string " + args_[2] + " = Console.ReadLine();";
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    string[] memes = toSay.Split('=');
                    return "object " + memes[0] + " = " + memes[1] + ";";
                }
            }
            else if (args_[0] == "set[]")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                string[] memes = toSay.Split('=');
                return "object[] " + memes[0] + " = " + memes[1] + ";";
            }
            else if (args_[0] == "color")
            {
                usingColor = true;
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "SetConsoleTextAttribute(GetStdHandle(-11), " + toSay + ");";

            }
            else if (args_[0] == "input")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.Write(" + toSay + ");" + "string " + args_[1] + " = Console.ReadLine();";
            }
            else if (args_[0] == "int_input")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.Write(" + toSay + ");" + "int " + args_[1] + " = int.Parse(Console.ReadLine());";
            }
            else if (args_[0] == "parse")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 2)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                if (args_[1] == "int")
                {
                    return "int " + args_[3] + " = int.Parse(" + args_[2] + ".ToString());";
                }
                else if (args_[1] == "float")
                {
                    return "float " + args_[3] + " = float.Parse(" + args_[2] + ".ToString());";
                }
                else if (args_[1] == "double")
                {
                    return "double " + args_[3] + " = dobule.Parse(" + args_[2] + ".ToString());";
                }
                else if (args_[1] == "string")
                {
                    return "string " + args_[3] + " = " + args_[2] + ".ToString();";
                }

            }
            else if (args_[0].StartsWith(":"))
            {

                return args_[0].TrimStart(':') + ": ";
            }
            else if (args_[0] == "goto")
            {
                return "goto " + args_[1] + ";";
            }
            else if (args_[0] == "clear" || args_[0] == "cls")
            {
                return "Console.Clear();";
            }
            else if (args_[0] == "sleep")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                return "System.Threading.Thread.Sleep(" + toSay + ");";
            }
            else if (args_[0] == "title")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.Title = " + toSay + ";";
            }
            else if (args_[0] == "file")
            {
                if (args_[1] == "write")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "System.IO.File.WriteAllText(" + args_[2] + "," + toSay + ");" + Environment.NewLine;
                }
                else if (args_[1] == "read")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "string " + args_[2] + " = " + "System.IO.File.ReadAllText(" + toSay + ");" + Environment.NewLine;
                }
            }
            else if (args_[0] == "copy")
            {
                return "File.Copy(" + args_[1] + ", " + args_[2] + ");";
            }
            else if (args_[0] == "move")
            {

                return "File.Move(" + args_[1] + ", " + args_[2] + ");";
            }
            else if (args_[0] == "delete")
            {
                return "File.Delete(" + args_[1] + ");";
            }
            else if (args_[0] == "create")
            {
                return "File.Create(" + args_[1] + ");";
            }
            else if (args_[0] == "replace")
            {
                return "File.Replace(" + args_[1] + ");";
            }
            else if (args_[0] == "exists")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "bool " + args_[1] + " = File.Exists(" + toSay + ");";
            }
            else if (args_[0] == "mail")
            {
                if (args_[1] == "new")
                {
                    new_mail_name = args_[2];
                    return "MailMessage mail_" + new_mail_name + " = new MailMessage();    SmtpClient SmtpServer_" + new_mail_name + " = new SmtpClient(" + args_[3] + ");";
                }
                else if (args_[1] == "credentials")
                {
                    return " mail_" + new_mail_name + ".From = new MailAddress(" + args_[2] + "); SmtpServer_" + new_mail_name + ".Credentials = new System.Net.NetworkCredential(" + args_[2] + ", " + args_[3] + "); ";
                }
                else if (args_[1] == "add_to")
                {
                    return "mail_" + new_mail_name + ".To.Add(" + args_[2] + ");";
                }
                else if (args_[1] == "port")
                {
                    return "SmtpServer_" + new_mail_name + ".Port = " + args_[2] + ";";
                }
                else if (args_[1] == "body")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "mail_" + new_mail_name + ".Body = " + toSay + ";";
                }
                else if (args_[1] == "subject")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "mail_" + new_mail_name + ".Subject = " + toSay + ";";
                }
                else if (args_[1] == "sll")
                {
                    return "SmtpServer_" + new_mail_name + ".EnableSsl = " + args_[2] + ";";
                }
                else if (args_[1] == "send")
                {
                    return "SmtpServer_" + new_mail_name + ".Send(mail_" + new_mail_name + "); ";
                }
            }
            else if (args_[0] == "exit")
            {
                return "Environment.Exit(0);";
            }
            else if (args_[0] == "msgbox")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "MessageBox.Show(" + toSay + ");";
            }
            else if (args_[0] == "start")
            {
                if (args_[2] != string.Empty)
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Process.Start(" + args_[1] + "," + toSay + ");";
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Process.Start(" + toSay + ");";
                }
            }
            else if (args_[0] == "console")
            {
                if (args_[1] == "show")
                {
                    return "var handle = GetConsoleWindow();  ShowWindow(handle, SW_SHOW); " + Environment.NewLine;
                }
                else if (args_[1] == "hide")
                {
                    return "var handle = GetConsoleWindow();  ShowWindow(handle, SW_HIDE); " + Environment.NewLine;
                }
                else if (args_[1] == "set_window_size")
                {
                    return "Console.SetWindowSize(" + args_[2] + ", " + args_[3] + ");";
                }
                else if (args_[1] == "cursor")
                {

                    if (args_[2] == "move")
                    {
                        return "Console.SetCursorPosition(" + args_[3] + ", " + args_[4] + ");";
                    }
                }
                else if (args_[1] == "font")
                {
                    usingCoord = true;
                    usingConsoleFont = true;

                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "SetConsoleFont(" + toSay + ", " + args_[2] + ");";
                }


            }
            else if (args_[0] == "dir")
            {
                if (args_[1] == "create")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Directory.CreateDirectory(" + toSay + ");";

                }
            }
            else if (args_[0] == "sendkeys")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "SendKeys.SendWait(" + toSay + ");";
            }
            else if (args_[0] == "random" || args_[0] == "rand")
            {
                if (args_[1] == "letter")
                {
                    return " int num = rand.Next(0, 26);  char let = (char)('a' + num); string " + args_[2] + " = let.ToString(); ";
                }
                else
                {
                    return "int " + args_[1] + " = rand.Next(" + args_[2] + "," + args_[3] + ");";
                }

            }
            else if (args_[0] == "forms" || args_[0] == "f")
            {
                if (args_[1] == "new")
                {
                    return "Form " + args_[2] + " = new Form();" + Environment.NewLine;
                }
                else if (args_[1] == "show")
                {
                    if (args_[2] == "show_normal")
                    {
                        return args_[3] + ".Show();";
                    }
                    else
                    {
                        return args_[2] + ".ShowDialog();";
                    }
                }
                else if (args_[1] == "close")
                {
                    return args_[3] + ".Close();";
                }
                if (args_[1] == "hide")
                {
                    return args_[2] + ".Hide();";
                }
                else
                {
                    string formName = args_[1];


                    if (args_[2] == "new")
                    {
                        if (args_[3] == "label")
                        {
                            return "Label " + args_[4] + " = new Label();" + Environment.NewLine;
                        }
                        else if (args_[3] == "textbox")
                        {
                            return "TextBox " + args_[4] + " = new TextBox();" + Environment.NewLine;
                        }
                        else if (args_[3] == "richtextbox")
                        {
                            return "RichTextBox " + args_[4] + " = new RichTextBox();" + Environment.NewLine;
                        }
                        else if (args_[3] == "trackbar")
                        {
                            return "TrackBar " + args_[4] + " = new TrackBar();" + Environment.NewLine;
                        }
                        else if (args_[3] == "tabcontrol")
                        {
                            return "TabControl " + args_[4] + " = new TabControl();" + Environment.NewLine;
                        }
                        else if (args_[3] == "button")
                        {
                            return "Button " + args_[4] + " = new Button();" + Environment.NewLine;
                        }
                        else if (args_[3] == "menustrip")
                        {
                            return "MenuStrip " + args_[4] + " = new MenuStrip();" + Environment.NewLine;
                        }
                        else if (args_[3] == "openfiledialog")
                        {
                            return "OpenFileDialog " + args_[4] + " = new OpenFileDialog();" + Environment.NewLine;
                        }

                    }
                    else if (args_[2] == "add")
                    {
                        return formName + ".Controls.Add(" + args_[3] + ");";
                    }
                    else if (args_[2] == "settings")
                    {

                        string toSay = "";
                        int counter_ = 0;
                        foreach (string arg in args_)
                        {
                            if (counter_ > 2)
                            {
                                toSay += arg + " ";
                            }
                            counter_++;
                        }

                        return formName + "." + toSay + ";";
                    }
                    else if (args_[2] == "get")
                    {
                        return "object " + args_[3] + " = " + args_[4] + "." + args_[5] + ";";
                    }
                    else if (args_[2] == "get_string")
                    {
                        return "string " + args_[3] + " = " + args_[4] + "." + args_[5] + ";";
                    }
                    else if (args_[2] == "function" || args_[2] == "func")
                    {
                        return args_[3] + "." + args_[4] + "();";
                    }
                    else
                    {
                        string toSay = "";
                        int counter_ = 0;
                        foreach (string arg in args_)
                        {
                            if (counter_ > 3)
                            {
                                toSay += arg + " ";
                            }
                            counter_++;
                        }

                        if (args_[3] == "click".ToLower())
                        {
                            return args_[2] + ".Click += (s, e) => {" + ToCSharp(toSay) + " };" + Environment.NewLine;
                        }
                        if (args_[3] == "Items")
                        {
                            string toSay2 = "";
                            int counter_2 = 0;
                            foreach (string arg in args_)
                            {
                                if (counter_2 > 4)
                                {
                                    toSay2 += arg + " ";
                                }
                                counter_2++;
                            }

                            return args_[2] + "." + args_[3] + "." + args_[4] + "(" + toSay2 + ");";
                        }
                        else
                        {
                            string toSay2 = "";
                            int counter_2 = 0;
                            foreach (string arg in args_)
                            {
                                if (counter_2 > 4)
                                {
                                    toSay2 += arg + " ";
                                }
                                counter_2++;
                            }

                            return args_[2] + "." + args_[3] + toSay + ";" + Environment.NewLine;

                        }
                    }


                }

            }
            else if (args_[0] == "sound")
            {
                if (args_[1] == "play")
                {
                    return "Soundplayer.SoundLocation = " + args_[2] + ";" + Environment.NewLine +
                    "Soundplayer.Load();" + Environment.NewLine +
                    "Soundplayer.Play();" + Environment.NewLine;
                }
                else if (args_[1] == "asterisk")
                {
                    return "System.Media.SystemSounds.Asterisk.Play();" + Environment.NewLine;
                }
                else if (args_[1] == "beep")
                {
                    return "System.Media.SystemSounds.Beep.Play();" + Environment.NewLine;
                }
                else if (args_[1] == "question")
                {
                    return " System.Media.SystemSounds.Question.Play();" + Environment.NewLine;
                }
                else if (args_[1] == "exclamation")
                {
                    return " System.Media.SystemSounds.Exclamation.Play();" + Environment.NewLine;
                }
                else if (args_[1] == "hand")
                {
                    return " System.Media.SystemSounds.Hand.Play();" + Environment.NewLine;
                }
            }
            else if (args_[0] == "reg")
            {
                if (args_[1] == "create_sub")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.CurrentUser.CreateSubKey(" + @toSay + ");";
                }
                else if (args_[1] == "delete_sub")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.CurrentUser.DeleteSubKey(" + @toSay + ");";
                }
                else if (args_[1] == "set_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.SetValue(" + @args_[2] + "," + @args_[3] + "," + toSay + ", RegistryValueKind.String); " + Environment.NewLine;

                } else if (args_[1] == "startup_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(\"\\\\SOFTWAREMicrosoft\\\\Windows\\\\CurrentVersion\\\\Run\", true);" +
                        "  if (registryKey.GetValue(" + args_[2] + ") != " + toSay + ")" +
                    "{ registryKey.SetValue(" + args_[2] + ", " + toSay + ");  }  registryKey.Close();";
                }
                else if (args_[1] == "delete_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[2] + ");" +
                    "key.DeleteValue(" + args_[3] + "," + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
                else if (args_[1] == "delete_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[3] + ");" +
                    "string " + args_[2] + " =  key.GetValue(" + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
                else if (args_[1] == "get_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[2] + ");" +
                    "key.DeleteValue(" + args_[3] + "," + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
            }
            else if (args_[0] == "thread")
            {
                if (args_[1] == "start")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    int dab = random.Next(999, 99999);

                    return "ThreadStart childref_" + dab.ToString() + " = new ThreadStart(" + toSay + ");" + Environment.NewLine +
                        "Thread childThread" + dab.ToString() + " = new Thread(childref_" + dab.ToString() + ");" + Environment.NewLine +
                        "childThread" + dab.ToString() + ".Start();" + Environment.NewLine;
                }
            }
            else if (args_[0] == "mouse")
            {
                if (args_[1] == "left_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.LEFTDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "left_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.LEFTUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "right_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.RIGHTUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "right_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.RIGHTDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "middle_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.MIDDLEDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "middle_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.MIDDLEUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "get_pos_x")
                {
                    return "GetCursorPos(out pt); int " + args_[2] + " = pt.X;";
                }
                else if (args_[1] == "get_pos_y")
                {
                    return "GetCursorPos(out pt); int " + args_[2] + " = pt.Y;";
                }


            }
            else if (args_[0] == "speech")
            {
                usingSpeech = true;


                if (args_[1] == "speak")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "speechSynthesizer.SpeakAsync(" + toSay + ");";
                }
                else if (args_[1] == "volume")
                {
                    return "speechSynthesizer.Volume = " + args_[2] + ";";
                }
                else if (args_[1] == "rate")
                {
                    return "speechSynthesizer.Rate = " + args_[2] + ";";
                }
            }
            else if (args_[0] == "speech_rec")
            {
                usingRecEngine = true;

                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                if (args_[1] == "commands")
                {
                    return " Choices commands = new Choices(); " + Environment.NewLine +
                    "commands.Add(" + toSay + " ); " + Environment.NewLine +
                   " GrammarBuilder grammarBuilder = new GrammarBuilder();" + Environment.NewLine +
                    "grammarBuilder.Append(commands);" + Environment.NewLine +
                    "Grammar grammar = new Grammar(grammarBuilder);" + Environment.NewLine;
                }
                else if (args_[1] == "event" || args_[1] == "func")
                {
                    return "speechRecognitionEngine.LoadGrammarAsync(grammar);" + Environment.NewLine +
                    "speechRecognitionEngine.SetInputToDefaultAudioDevice();" + Environment.NewLine +
                    "speechRecognitionEngine.SpeechRecognized += " + toSay + ";" + Environment.NewLine;
                }
                else if (args_[1] == "start")
                {
                    return "speechRecognitionEngine.RecognizeAsync(RecognizeMode.Multiple);";
                }
                else if (args_[1] == "stop")
                {
                    return "speechRecognitionEngine.RecognizeAsyncStop();";
                }

            }
            else if (args_[0] == "window")
            {
                if (!usingWindow)
                {
                    usingWindow = true;
                }

                if (args_[1] == "find")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "IntPtr " + args_[2] + " = FindWindow(" + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "set_long")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "SetWindowLong(" + args_[2] + ", " + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "get_long")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "int " + args_[2] + " = GetWindowLong(" + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "get_rect")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "GetWindowRect(" + args_[2] + ", out " + toSay + ");";
                }

            }
            else if (args_[0] == "system")
            {
                if (args_[1] == "volume")
                {
                    // PUT HANDLE FOR ARGS 3
                    usingVolume = true;
                    if (args_[2] == "up")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND," + args_[3] + ",  (IntPtr)APPCOMMAND_VOLUME_UP); ";
                    }
                    else if (args_[2] == "down")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND, " + args_[3] + ", (IntPtr)APPCOMMAND_VOLUME_DOWN); ";
                    }
                    else if (args_[2] == "mute")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND, " + args_[3] + ", (IntPtr)APPCOMMAND_VOLUME_MUTE); ";
                    }
                }
                if (args_[1] == "keys")
                {
                    usingKeys = true;

                    if (args_[2] == "press_event")
                    {
                        return "gHook = new GlobalKeyboardHook(); " + Environment.NewLine +
                        "gHook.KeyDown += new KeyEventHandler(" + args_[3] + "); " + Environment.NewLine +
                        "foreach (Keys key in Enum.GetValues(typeof(Keys))) " + Environment.NewLine +
                            "gHook.HookedKeys.Add(key); " + Environment.NewLine;
                    }
                    else if (args_[2] == "hook" || args_[2] == "start")
                    {
                        return "gHook.hook();";
                    }
                    else if (args_[2] == "unhook" || args_[2] == "stop")
                    {
                        return "gHook.unhook();";
                    }
                }
            }
            else if (args_[0] == "graphics" || args_[0] == "g")
            {
                usingGraphics = true;
                if (args_[1] == "event")
                {
                    return args_[2] + ".Paint += new PaintEventHandler(" + args_[3] + ");";
                }
                else if (args_[1] == "draw_image")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "e.Graphics.DrawImage(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_rectangle")
                {
                    return "e.Graphics.DrawRectangle(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_line")
                {
                    return "e.Graphics.DrawLine(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_string" || args_[1] == "draw_text")
                {
                    return "e.Graphics.DrawString(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_arc")
                {
                    return "e.Graphics.DrawArc(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_bezier")
                {
                    return "e.Graphics.DrawBezier(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_ellipse")
                {
                    return "e.Graphics.DrawEllipse(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "draw_pie")
                {
                    return "e.Graphics.PieArc(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "fill_rectangle")
                {
                    return "e.Graphics.FillRectangle(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "fill_ellipse")
                {
                    return "e.Graphics.FillEllipse(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }
                else if (args_[1] == "fill_pie")
                {
                    return "e.Graphics.FillPie(" + args_[2] + ", " + args_[3] + ", " + args_[4] + ", " + args_[5] + ", " + args_[6] + "); ";
                }

            }
            else if (args_[0] == "taskkill")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                Random random = new Random();
                string name = "process_" + random.Next(0, 9999999).ToString();
                return "Process[] " + name + " = Process.GetProcessesByName(" + toSay + ", Environment.MachineName); " + name + "[0].Kill();";

            }
            else if (args_[0] == "imap")
            {
                usingImap = true;
                if (args_[1] == "new")
                {
                    return "ImapClient " + args_[2] + " = new ImapClient(" + args_[3] + ", " + args_[4] + "," + args_[5] + ", " + args_[6] + ", AuthMethod.Login, true);";
                }
                else if (args_[1] == "event")
                {
                    return args_[2] + ".NewMessage += new EventHandler<IdleMessageEventArgs>(" + args_[3] + ");";
                }
                else if (args_[1] == "message_load")
                {
                    return "MailMessage message = e.Client.GetMessage(e.MessageUID, FetchOptions.Normal);";
                } else if (args_[1] == "get")
                {
                    return "string " + args_[2] + " = message." + args_[3] + ";";
                }
            }
            else if (args_[0] == "void")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                usingVoids = true;

                if (args_[1].Contains("Main"))
                {
                    return Environment.NewLine + "static void " + "Main(string[] args)" + " {" + Environment.NewLine;
                }
                return Environment.NewLine + "static void " + toSay + Environment.NewLine;
            }
            else if (args_[0].Contains("}") || args_[0].Contains("{") || (args_[0].Contains(";")))
            {
                string all = " ";
                foreach (string s in args_)
                {
                    all += s + " ";
                }
                return all.Trim();
            }
            else if (args_[0].Contains("Main()"))
            {
                return args_[0].Replace("Main()", "Main(args);");
            }
            else if (args_[0] == "global" || args_[0] == "public")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "static " + ToCSharp(toSay);
            }
            else if (args_[0] == "stor")
            {
                if (args_[1] == "read")
                {
                    usingBPPS = true;
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    string id = random.Next(0, 48294324).ToString();

                    return "string " + args_[2] + " = \" \"; string FileInfo" + id + " = File.ReadAllText(" + toSay + ");" + Environment.NewLine +
                    "FileInfo" + id + " = DecryptBPPS(FileInfo" + id + "); " + Environment.NewLine +
                    "string " + args_[2] + "_MeME = FileInfo" + id + ";" + Environment.NewLine +
                    "string[] FileInfoz_" + id + " = " + args_[2] + "_MeME.Split(';');" + Environment.NewLine +
                    "foreach (string s_" + id + " in FileInfoz_" + id + ") {" + Environment.NewLine +
                        "string[] temp = s_" + id + ".Split('='); if (temp[0] == " + args_[3] + ") { " + args_[2] + " = temp[1]; }" + Environment.NewLine +
                    "} "; 
                } else if (args_[1] == "write")
                {
                    usingBPPS = true;
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    string id = random.Next(0, 48294324).ToString();

                    return "string ENCRYPTED_" + id + " = EncryptBPPS(" + toSay + " + \";\"); " + Environment.NewLine +
                        "File.AppendAllText(" + args_[2] + ", ENCRYPTED_" + id + ");";


                }

                else if (args_[1] == "clear")
                {
                    usingBPPS = true;
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    string id = random.Next(0, 48294324).ToString();
                    return "File.Delete(" + toSay + ");" + Environment.NewLine;


                }

            }
            else if (args_[0] == "encrypt")
            {
                usingCryto = true;

                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 2)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                return "string " + args_[1] + " = Encrypt(" + toSay + ", " + args_[2] + ");";
            }
            else if (args_[0] == "decrypt")
            {
                usingCryto = true;

                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 2)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                return "string " + args_[1] + " = Decrypt(" + toSay + ", " + args_[2] + ");";
            }


            if (args_[0] != string.Empty && args_[0] != "while" && args_[0] != "foreach" && args_[0] != "for" && !args_[0].EndsWith("+") && !args_[0].EndsWith("{"))
            {

                //raw csharp code is here
                string all_ = " ";
                foreach (string s in args_)
                {
                    all_ += s + " ";
                }
                return all_.Trim() + ";";
            }

            return "";
        }

        static string ReplaceItems(string toReplce)
        {
            string Finished_Item = toReplce;

            if (toReplce.Contains("-ToString") || toReplce.Contains("-ToString"))
            {
                Finished_Item = Finished_Item.Replace("-tostring", ".ToString()");
            }

            if (toReplce.Contains("-ToChArarray") || toReplce.Contains("-ToChararray"))
            {
                Finished_Item = Finished_Item.Replace("-tochararray", ".ToCharArray()");
            }

            if (toReplce.Contains("-Length") || toReplce.Contains("-Length"))
            {
                Finished_Item = Finished_Item.Replace("-length", ".Length");
            }

            if (toReplce.Contains("-Parse"))
            {
                Finished_Item = Finished_Item.Replace("-Parse", ".Parse");
            }

            if (toReplce.Contains("-Text"))
            {
                Finished_Item = Finished_Item.Replace("-Text", ".Text");
            }

            if (usingRecEngine)
            {
                if (toReplce.Contains("rec_result"))
                {
                    Finished_Item = Finished_Item.Replace("rec_result", "e.Result.Text");
                }

                if (toReplce.Contains("rec_args"))
                {
                    Finished_Item = Finished_Item.Replace("rec_args", "SpeechRecognizedEventArgs e");
                }
            }

            if (usingKeys)
            {

                if (toReplce.Contains("key_value"))
                {
                    Finished_Item = Finished_Item.Replace("key_value", "((char)e.KeyValue).ToString()");
                }

                if (toReplce.Contains("key_args"))
                {
                    Finished_Item = Finished_Item.Replace("key_args", "KeyEventArgs e");
                }
            } 

            if (usingGraphics)
            {
                if (toReplce.Contains("graphics_args"))
                {
                    Finished_Item = Finished_Item.Replace("graphics_args", "PaintEventArgs e");
                }

                if (toReplce.Contains("g_args"))
                {
                    Finished_Item = Finished_Item.Replace("g_args", "PaintEventArgs e");
                }
            }

            if (toReplce.Contains("%cd%"))
            {
                Finished_Item = Finished_Item.Replace("%cd%", "Directory.GetCurrentDirectory();");
            }

            if (toReplce.Contains("computer_name"))
            {
                Finished_Item = Finished_Item.Replace("computer_name", "Environment.MachineName");
            }

            if (toReplce.Contains("computer_user_name"))
            {
                Finished_Item = Finished_Item.Replace("computer_user_name", "Environment.UserName");
            }

            if (toReplce.Contains("os_version"))
            {
                Finished_Item = Finished_Item.Replace("os_version", "Environment.OSVersion.ToString()");
            }

            if (toReplce.Contains("new_line"))
            {
                Finished_Item = Finished_Item.Replace("new_line", "Environment.NewLine");
            }

            if (toReplce.Contains("tick_count"))
            {
                Finished_Item = Finished_Item.Replace("tick_count", "Environment.TickCount");
            }
            
            if (usingImap)
            {
                if (toReplce.Contains("imap_args"))
                {
                    Finished_Item = Finished_Item.Replace("imap_args", "IdleMessageEventArgs e");
                }
            }

            if (toReplce.Contains("console_caps_lock"))
            {
                Finished_Item = Finished_Item.Replace("console_caps_lock", "Console.CapsLock");
            }
            if (toReplce.Contains("console_background_color"))
            {
                Finished_Item = Finished_Item.Replace("console_background_color", "Console.BackgroundColor");
            }
            if (toReplce.Contains("console_foreground_color"))
            {
                Finished_Item = Finished_Item.Replace("console_foreground_color", "Console.ForegroundColor");
            }
            if (toReplce.Contains("console_foreground_color"))
            {
                Finished_Item = Finished_Item.Replace("console_foreground_color", "Console.ForegroundColor");
            }
            if (toReplce.Contains("console_buffer_height"))
            {
                Finished_Item = Finished_Item.Replace("console_budffer_height", "Console.BufferHeight");
            }
            if (toReplce.Contains("console_buffer_width"))
            {
                Finished_Item = Finished_Item.Replace("console_buffer_width", "Console.BufferHeight");
            }
            if (toReplce.Contains("console_cursor_left"))
            {
                Finished_Item = Finished_Item.Replace("console_buffer_left", "Console.CursorLeft");
            }
            if (toReplce.Contains("console_cursor_top"))
            {
                Finished_Item = Finished_Item.Replace("console_buffer_top", "Console.CursorTop");
            }


            return Finished_Item;
        }

        static string new_mail_name = "mail";
        static bool usingVoids = false;
        static bool usingSpeech = false;

        static string dllImports = "static System.Media.SoundPlayer Soundplayer = new System.Media.SoundPlayer();" + Environment.NewLine +
            "[DllImport(\"kernel32.dll\")]  " + Environment.NewLine +
            "static extern IntPtr GetConsoleWindow();   " + Environment.NewLine +
        "[DllImport(\"user32.dll\")]  " + Environment.NewLine +
        "static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);  " + Environment.NewLine +
       " const int SW_HIDE = 0;  " + Environment.NewLine +
        "const int SW_SHOW = 5;  " + Environment.NewLine +
            "[DllImport(\"user32.dll\", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]" + Environment.NewLine +
        "public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dxExtraInfo);" + Environment.NewLine +
        "[Flags]" + Environment.NewLine +
        "public enum MouseEventFlags { LEFTDOWN = 0x00000002, LEFTUP = 0x00000004, MIDDLEDOWN = 0x00000020,   MIDDLEUP = 0x00000040,MOVE = 0x00000001,ABSOLUTE = 0x00008000, RIGHTDOWN = 0x00000008, RIGHTUP = 0x00000010, WHEEL = 0x00000800,XDOWN = 0x00000080, XUP = 0x00000100  }" + Environment.NewLine +
            " [DllImport(\"user32.dll\")] " + Environment.NewLine +
                     "public static extern bool GetCursorPos(out Point lpPoint);" + Environment.NewLine;


        static bool usingRecEngine = false;
        static string Rec_Engine = " ";


        static bool usingWindow = false;
        static bool usingVolume = false;
        static bool usingKeys = false;
        static bool usingGraphics = false;
        static bool usingImap = false;
        static bool usingColor = false;
        static bool usingConsoleFont = false;
        static bool usingCoord = false;
        static bool usingBPPS = false;
        static bool usingCryto = false;

        static void Compile(string fileName, string toCompile, string options)
        {
            CodeDomProvider codeProvider = CodeDomProvider.CreateProvider("CSharp");

            System.CodeDom.Compiler.CompilerParameters parameters = new CompilerParameters();
            //Make sure we generate an EXE, not a DLL
            parameters.GenerateExecutable = true;
            parameters.CompilerOptions = options;
            parameters.OutputAssembly = fileName;
            parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
            parameters.ReferencedAssemblies.Add("System.dll");
            parameters.ReferencedAssemblies.Add("System.Drawing.dll");
            parameters.ReferencedAssemblies.Add("System.Security.dll");
            parameters.ReferencedAssemblies.Add(@"C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0\Profile\Client\System.Speech.dll");
            if (usingImap)
            {
                parameters.ReferencedAssemblies.Add("S22.Imap.dll");
            }

            CompilerResults results = codeProvider.CompileAssemblyFromSource(parameters, toCompile);

            if (results.Errors.Count > 0)
            {
                foreach (CompilerError CompErr in results.Errors)
                {
                    Console.WriteLine(
                                "Line number " + CompErr.Line + " : " + CompErr.Column +
                                ", Error Number: " + CompErr.ErrorNumber +
                                ", '" + CompErr.ErrorText + ";");
                    Console.ReadKey();

                }
            }
            else
            {
                //Successful Compile
                Console.WriteLine("Success! - " + fileName);
            }
        }


        static string EncryptionKey = " ";
    }
}