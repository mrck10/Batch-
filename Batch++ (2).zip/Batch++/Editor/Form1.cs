﻿

namespace Editor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textEditorControl2_Load(object sender, EventArgs e)
        {
            string dirc = Application.StartupPath;
            FileSyntaxModeProvider fsmp;
            if (Directory.Exists(dirc))
            {

                fsmp = new FileSyntaxModeProvider(dirc);
                HighlightingManager.Manager.AddSyntaxModeFileProvider(fsmp);
                textEditorControl2.SetHighlighting("B++");

            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textEditorControl2.Text = "void Main() {" + Environment.NewLine +
                "pause \" hello world \" " + Environment.NewLine +
                "}";
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textEditorControl2.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textEditorControl2.Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

            openFileDialog1.Title = "Open a Batch Plus Plus File.";



            openFileDialog1.CheckFileExists = true;

            openFileDialog1.CheckPathExists = true;



            openFileDialog1.DefaultExt = "bpp";

            openFileDialog1.Filter = "B++ files (*.bpp)|*.bpp|All files (*.*)|*.*";

            openFileDialog1.FilterIndex = 1;

            openFileDialog1.RestoreDirectory = true;



            openFileDialog1.ReadOnlyChecked = true;

            openFileDialog1.ShowReadOnly = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {

                textEditorControl2.Text = File.ReadAllText(openFileDialog1.FileName);
                fileName = openFileDialog1.FileName;
                StoreData(fileName);

            }
        }

        private string fileName = "";

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (fileName != string.Empty)
                {
                    File.WriteAllText(fileName, textEditorControl2.Text);
                }
                else
                {
                    SaveAs();
                }
            } catch
            {
                SaveAs();
            }
        }

        void SaveAs()
        {
            saveFileDialog1.Title = "Save Batch Plus Plus Files";

            saveFileDialog1.CheckPathExists = true;

            saveFileDialog1.DefaultExt = "bpp";

            saveFileDialog1.Filter = "B++ files (*.bpp)|*.bpp|All files (*.*)|*.*";

            saveFileDialog1.FilterIndex = 1;

            saveFileDialog1.RestoreDirectory = true;



            if (saveFileDialog1.ShowDialog() == DialogResult.OK)

            {
                File.WriteAllText(saveFileDialog1.FileName, textEditorControl2.Text);
                fileName = saveFileDialog1.FileName;
                StoreData(fileName);
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveAs();
        }

        private void compileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Title = "Compile";


                saveFileDialog.DefaultExt = "exe";

                saveFileDialog.Filter = "Executeables (*.exe)|*.exe";

                saveFileDialog.FilterIndex = 1;


                if (saveFileDialog.ShowDialog() == DialogResult.OK)

                {
                    File.WriteAllText(@saveFileDialog.FileName, @textEditorControl2.Text);
                    Process.Start(@"BPP_COMPILE.exe", @saveFileDialog.FileName + " " + @saveFileDialog.FileName);
                }
            } catch (Exception eg)
            {
                MessageBox.Show(eg.Message);
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = fontDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                Font font = fontDialog1.Font;
               textEditorControl2.Font = font;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Title = "Compile";


                saveFileDialog.DefaultExt = "exe";

                saveFileDialog.Filter = "Executeables (*.exe)|*.exe";

                saveFileDialog.FilterIndex = 1;


                if (saveFileDialog.ShowDialog() == DialogResult.OK)

                {
                    File.WriteAllText(@saveFileDialog.FileName, @textEditorControl2.Text);
                    Process.Start(@"BPP_COMPILE.exe", @saveFileDialog.FileName + " " + @saveFileDialog.FileName);
                    //MessageBox.Show(@saveFileDialog.FileName);
                    Thread.Sleep(1000);
                    Process.Start(@saveFileDialog.FileName);
                }
            } catch (Exception e_)
            {
                MessageBox.Show(e_.Message);
            }
}

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                fileName = @File.ReadAllText("Editor_Data.txt");
                textEditorControl2.Text = File.ReadAllText(fileName);

            } catch
            {
                File.Create("Editor_Data.txt");
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                    File.WriteAllText(fileName, @textEditorControl2.Text);
                    Process.Start(@"BPP_COMPILE.exe", @fileName + " " + @fileName + ".exe");
                Thread.Sleep(1000);
                Process.Start(@fileName + ".exe");
            }
            catch (Exception e_)
            {
                MessageBox.Show("Something went wrong when compiling");
            }
        }

        void StoreData(string data)
        {
            File.WriteAllText("Editor_Data.txt", data);
        }
    }
}
