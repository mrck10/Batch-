﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bpp
{
    public class console
    {
        public string input(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        public int int_input(string prompt)
        {
            Console.Write(prompt);
            int i_;
            int.TryParse(Console.ReadLine(), out i_);
            return i_;
        }

        public void sleep(int miliseconds)
        {
            Thread.Sleep(miliseconds);
        }


        public void sendkeys(string keys)
        {
            System.Windows.Forms.SendKeys.SendWait(keys);
        }

        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        const int SW_HIDE = 0;
        const int SW_SHOW = 5;

        public void console_hide()
        {
            var handle = GetConsoleWindow(); ShowWindow(handle, SW_HIDE);
        }

        public void console_show()
        {
            var handle = GetConsoleWindow(); ShowWindow(handle, SW_SHOW);
        }


    }

    public class mouse
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dxExtraInfo);
        [Flags]
        public enum MouseEventFlags { LEFTDOWN = 0x00000002, LEFTUP = 0x00000004, MIDDLEDOWN = 0x00000020, MIDDLEUP = 0x00000040, MOVE = 0x00000001, ABSOLUTE = 0x00008000, RIGHTDOWN = 0x00000008, RIGHTUP = 0x00000010, WHEEL = 0x00000800, XDOWN = 0x00000080, XUP = 0x00000100 }
        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out Point lpPoint);

        public void mouse_click(MouseEventFlags mouseEventFlags, int x, int y)
        {
            Cursor.Position = new Point(x, y);
            mouse_event((int)(mouseEventFlags), 0, 0, 0, 0);
        }

        public int current_x
        {
            get
            {
                Point quick_point;
                GetCursorPos(out quick_point);
                return quick_point.X;
            }
        }

        public int current_y
        {
            get
            {
                Point quick_point;
                GetCursorPos(out quick_point);
                return quick_point.Y;
            }
        }
    }

    public class window
    {
        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetWindowRect(IntPtr hwnd, out RECT lpRect);

        public struct RECT
        {
            public int left, top, right, bottom;
        }
    }

    public class system
    {

        public class volume
        {
            private const int APPCOMMAND_VOLUME_MUTE = 0x80000;
            private const int APPCOMMAND_VOLUME_UP = 0xA0000;
            private const int APPCOMMAND_VOLUME_DOWN = 0x90000;
            private const int WM_APPCOMMAND = 0x319;

            [DllImport("user32.dll")]
            public static extern IntPtr SendMessageW(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

            public void up(IntPtr Form_Handle)
            {
                SendMessageW(Form_Handle, WM_APPCOMMAND, Form_Handle, (IntPtr)APPCOMMAND_VOLUME_UP);
            }

            public void down(IntPtr Form_Handle)
            {
                SendMessageW(Form_Handle, WM_APPCOMMAND, Form_Handle, (IntPtr)APPCOMMAND_VOLUME_DOWN);
            }

            public void mute(IntPtr Form_Handle)
            {
                SendMessageW(Form_Handle, WM_APPCOMMAND, Form_Handle, (IntPtr)APPCOMMAND_VOLUME_MUTE);
            }
        }

        public class keys
        {
            [DllImport("user32.dll")] static extern int CallNextHookEx(IntPtr hhk, int code, int wParam, ref keyBoardHookStruct lParam);[DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int idHook, LLKeyboardHook callback, IntPtr hInstance, uint theardID);[DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hInstance);[DllImport("kernel32.dll")] static extern IntPtr LoadLibrary(string lpFileName); public delegate int LLKeyboardHook(int Code, int wParam, ref keyBoardHookStruct lParam); public struct keyBoardHookStruct { public int vkCode; public int scanCode; public int flags; public int time; public int dwExtraInfo; }
            const int WH_KEYBOARD_LL = 13; const int WM_KEYDOWN = 0x0100; const int WM_KEYUP = 0x0101; const int WM_SYSKEYDOWN = 0x0104; const int WM_SYSKEYUP = 0x0105;

            LLKeyboardHook llkh; public List<Keys>
            HookedKeys = new List<Keys>(); IntPtr Hook = IntPtr.Zero;
            public event KeyEventHandler KeyDown; public event KeyEventHandler KeyUp; public keys()
            {
                llkh = new LLKeyboardHook(HookProc);
            }
            ~keys() { unhook(); }
            public void hook()
            {
                IntPtr hInstance = LoadLibrary("User32");
                Hook = SetWindowsHookEx(WH_KEYBOARD_LL, llkh, hInstance, 0);
            }
            public void unhook() { UnhookWindowsHookEx(Hook); }


            public int HookProc(int Code, int wParam, ref keyBoardHookStruct lParam)
            {
                if (Code >= 0)
                {
                    Keys key = (Keys)lParam.vkCode;
                    if (HookedKeys.Contains(key))
                    {
                        KeyEventArgs kArg = new KeyEventArgs(key);
                        if ((wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) && (KeyDown != null)) KeyDown(this, kArg);
                        else if ((wParam == WM_KEYUP || wParam == WM_SYSKEYUP) && (KeyUp != null)) KeyUp(this, kArg);
                        if (kArg.Handled) return 1;
                    }

                }
                return CallNextHookEx(Hook, Code, wParam, ref lParam);
            }
        }
    }

    public class process_memeory
    {
        const int PROCESS_WM_READ = 0x0010;

        [DllImport("kernel32.dll")]
        static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        static extern bool ReadProcessMemory(int hProcess,
          int lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(int hProcess, int lpBaseAddress,
          byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesWritten);

        public static void read_bytes(Int32 adress, byte[] out_array)
        {
            Process process = Process.GetProcessesByName(process_name)[0];
            IntPtr processHandle = OpenProcess(PROCESS_WM_READ, false, process.Id);

            int bytesRead = 0;


            // 0x0046A3B8 is the address where I found the string, replace it with what you found
            ReadProcessMemory((int)processHandle, adress, out_array, out_array.Length, ref bytesRead);
        }

        const int PROCESS_VM_WRITE = 0x0020;
        const int PROCESS_VM_OPERATION = 0x0008;

        public static void write_string(Int32 adress, string toWrite)
        {
            Process process = Process.GetProcessesByName(process_name)[0];
            IntPtr processHandle = OpenProcess(0x1F0FFF, false, process.Id);

            int bytesWritten = 0;
            byte[] buffer = Encoding.Unicode.GetBytes(toWrite);

            WriteProcessMemory((int)processHandle, adress, buffer, buffer.Length, ref bytesWritten);
        }

        public static void write_bytes(Int32 adress, byte[] toWrite)
        {
            Process process = Process.GetProcessesByName(process_name)[0];
            IntPtr processHandle = OpenProcess(0x1F0FFF, false, process.Id);

            int bytesWritten = 0;
            byte[] buffer = toWrite;

            WriteProcessMemory((int)processHandle, adress, buffer, buffer.Length, ref bytesWritten);
        }

        public static string process_name;

        public process_memeory(string process_name) {
            process_memeory.process_name = process_name;
        }
    }
}
