﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPP_C_COMPILER
{
    class Program
    {
        static void Main(string[] args)
        {
            string toCompile = "";

            int counter = 0;
            string line;

            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(args[0]);
            while ((line = file.ReadLine()) != null)
            {
                toCompile += ToCSharp(ReplaceItems(line));
            }


            counter++;

            file.Close();

            string SomeThingsToAdd_using = //"#include \"stdafx.h\"" + Environment.NewLine +
            "#include <iostream>" + Environment.NewLine +
            "#include <stdio.h>" + Environment.NewLine +
            "#include <string>" + Environment.NewLine +
            "#include <fstream>" + Environment.NewLine +
            "#include <sstream>" + Environment.NewLine +
            "#include <Windows.h>" + Environment.NewLine +
            "using namespace std;" + Environment.NewLine;


            string SomeThingsToAdd_inside = " " + Environment.NewLine;
            string Other_Classes = " " + Environment.NewLine;

            if (usingFile)
            {
                   Other_Classes += "void _WriteFile(string fileName, string fileContent)  " + Environment.NewLine +
             "   {" + Environment.NewLine +
                   "    ofstream myfile; " + Environment.NewLine +
                   "    myfile.open(fileName); " + Environment.NewLine +
                   "    myfile << fileContent; " + Environment.NewLine +
                   "    myfile.close(); " + Environment.NewLine +
                "}" + Environment.NewLine;

                    Other_Classes += "string _ReadFile(string fileName) {" + Environment.NewLine +
         "string toReturn = \" \"; ifstream myfile(fileName); " + Environment.NewLine +
                "if (myfile.is_open()) " + Environment.NewLine +
                "{ " + Environment.NewLine +
                    "string line; while (std::getline(myfile, line)) { toReturn += line; } myfile.close(); return toReturn; " + Environment.NewLine +
                "} " + Environment.NewLine +
               " else cout << \"Unable to open file\"; " + Environment.NewLine +
            "} " + Environment.NewLine;

            }

            string FinishedProduct = SomeThingsToAdd_using + Other_Classes + toCompile;

            Console.WriteLine(FinishedProduct);
            Compile(args[1], FinishedProduct);

        }

        static Random random = new Random();

        static string ToCSharp(string line)
        {
            string[] args_ = (line).Trim().Split(' ');

            if (args_[0] == "echo" || args_[0] == "print" || args_[0] == "say")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "cout << " + toSay + " << endl;" + Environment.NewLine;
            }
            else if (args_[0] == "echo_nl")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "cout << " + toSay + ";" + Environment.NewLine;
            }
            else if (args_[0] == "pause")
            {
                if (args_[1] == string.Empty)
                {
                    return "system(\"pause\");" + Environment.NewLine;
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "cout << " + toSay + "; system(\"pause\");" + Environment.NewLine;
                }

            }
            else if (args_[0] == "set")
            {
                if (args_[1] == "/p")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Console.Write(" + toSay + ");" + "string " + args_[2] + " = Console.ReadLine();";
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    string[] memes = toSay.Split('=');
                    return "object " + memes[0] + " = " + memes[1] + ";";
                }
            }
            else if (args_[0] == "color")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "Console.ForegroundColor = ConsoleColor." + toSay + ";";
            }
            else if (args_[0] == "input")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "cout << " + toSay + "; string " + args_[1] + " = \"\"; getline(cin, " + args_[1] + ");" + Environment.NewLine;
            }
            else if (args_[0].StartsWith(":"))
            {

                return args_[0].TrimStart(':') + ": ";
            }
            else if (args_[0] == "goto")
            {
                return "goto " + args_[1] + ";";
            }
            else if (args_[0] == "clear" || args_[0] == "cls")
            {
                return "system(\"cls\");";
            }
            else if (args_[0] == "sleep")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }

                return "_sleep(" + toSay + ");";
            }
            else if (args_[0] == "title")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "system(" + toSay + ");";

            }
            else if (args_[0] == "file")
            {
                usingFile = true;
                if (args_[1] == "write")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "_WriteFile(" + args_[2] + "," + toSay + ");";

                }
                else if (args_[1] == "read")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "string " + args_[2] + " = " + "_ReadFile(" + toSay + ");";
                }
            }
            else if (args_[0] == "copy")
            {
                return "system(copy " + args_[1] + " " + args_[2] + ");";
            }
            else if (args_[0] == "move")
            {

                return "system(move " + args_[1] + " " + args_[2] + ");";
            }
            else if (args_[0] == "delete")
            {
                return "system(delete " + args_[1] + ");";
            }
            else if (args_[0] == "create")
            {
                return "system(create " + args_[1] + ");";
            }
            else if (args_[0] == "replace")
            {
                return "system(replace " + args_[1] + ");";
            }
            else if (args_[0] == "exists")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 1)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "bool " + args_[1] + " = File.Exists(" + toSay + ");";
            }
            else if (args_[0] == "exit")
            {
                return "exit(0);";
            }
            else if (args_[0] == "msgbox")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "MessageBox(NULL, " + toSay + ", NULL, MB_OK);";
            }
            else if (args_[0] == "start")
            {
                if (args_[2] != string.Empty)
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "system(" + toSay + ");";
                }
                else
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 0)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Process.Start(" + toSay + ");";
                }
            }
            else if (args_[0] == "console")
            {
                if (args_[1] == "show")
                {
                    return "var handle = GetConsoleWindow();  ShowWindow(handle, SW_SHOW); " + Environment.NewLine;
                }
                else if (args_[1] == "hide")
                {
                    return "var handle = GetConsoleWindow();  ShowWindow(handle, SW_HIDE); " + Environment.NewLine;
                }
                else if (args_[1] == "set_window_size")
                {
                    return "Console.SetWindowSize(" + args_[2] + ", " + args_[3] + ");";
                }


            }
            else if (args_[0] == "dir")
            {
                if (args_[1] == "create")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Directory.CreateDirectory(" + toSay + ");";

                }
            }
            else if (args_[0] == "sendkeys")
            {
                string toSay = "";
                int counter_ = 0;
                foreach (string arg in args_)
                {
                    if (counter_ > 0)
                    {
                        toSay += arg + " ";
                    }
                    counter_++;
                }
                return "SendKeys.SendWait(" + toSay + ");";
            }
            else if (args_[0] == "reg")
            {
                if (args_[1] == "create_sub")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.CurrentUser.CreateSubKey(" + @toSay + ");";
                }
                else if (args_[1] == "delete_sub")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.CurrentUser.DeleteSubKey(" + @toSay + ");";
                }
                else if (args_[1] == "set_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "Registry.SetValue(" + @args_[2] + "," + @args_[3] + "," + toSay + ", RegistryValueKind.String); " + Environment.NewLine;

                }
                else if (args_[1] == "startup_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(\"\\\\SOFTWAREMicrosoft\\\\Windows\\\\CurrentVersion\\\\Run\", true);" +
                        "  if (registryKey.GetValue(" + args_[2] + ") != " + toSay + ")" +
                    "{ registryKey.SetValue(" + args_[2] + ", " + toSay + ");  }  registryKey.Close();";
                }
                else if (args_[1] == "delete_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[2] + ");" +
                    "key.DeleteValue(" + args_[3] + "," + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
                else if (args_[1] == "delete_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[3] + ");" +
                    "string " + args_[2] + " =  key.GetValue(" + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
                else if (args_[1] == "get_value")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }
                    return "RegistryKey key = Registry.CurrentUser.OpenSubKey(" + @args_[2] + ");" +
                    "key.DeleteValue(" + args_[3] + "," + toSay + "); " + Environment.NewLine +
                    "key.Close(); " + Environment.NewLine;
                }
            }
            else if (args_[0] == "thread")
            {
                if (args_[1] == "start")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 1)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    int dab = random.Next(999, 99999);

                    return "ThreadStart childref_" + dab.ToString() + " = new ThreadStart(" + toSay + ");" + Environment.NewLine +
                        "Thread childThread" + dab.ToString() + " = new Thread(childref_" + dab.ToString() + ");" + Environment.NewLine +
                        "childThread" + dab.ToString() + ".Start();" + Environment.NewLine;
                }
            }
            else if (args_[0] == "mouse")
            {
                if (args_[1] == "left_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.LEFTDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "left_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.LEFTUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "right_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.RIGHTUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "right_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.RIGHTDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "middle_down")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.MIDDLEDOWN), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "middle_up")
                {
                    return "Cursor.Position = new Point(" + args_[2] + "," + args_[3] + ");" + Environment.NewLine +
                    "mouse_event((int)(MouseEventFlags.MIDDLEUP), 0, 0, 0, 0);" + Environment.NewLine;
                }
                else if (args_[1] == "get_pos_x")
                {
                    return "GetCursorPos(out pt); int " + args_[2] + " = pt.X;";
                }
                else if (args_[1] == "get_pos_y")
                {
                    return "GetCursorPos(out pt); int " + args_[2] + " = pt.Y;";
                }


            }
            else if (args_[0] == "window")
            {
                if (!usingWindow)
                {
                    usingWindow = true;
                }

                if (args_[1] == "find")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "IntPtr " + args_[2] + " = FindWindow(" + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "set_long")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "SetWindowLong(" + args_[2] + ", " + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "get_long")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 3)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "int " + args_[2] + " = GetWindowLong(" + args_[3] + ", " + toSay + ");";
                }
                else if (args_[1] == "get_rect")
                {
                    string toSay = "";
                    int counter_ = 0;
                    foreach (string arg in args_)
                    {
                        if (counter_ > 2)
                        {
                            toSay += arg + " ";
                        }
                        counter_++;
                    }

                    return "GetWindowRect(" + args_[2] + ", out " + toSay + ");";
                }

            }
            else if (args_[0] == "system")
            {
                if (args_[1] == "volume")
                {
                    // PUT HANDLE FOR ARGS 3
                    usingVolume = true;
                    if (args_[2] == "up")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND," + args_[3] + ",  (IntPtr)APPCOMMAND_VOLUME_UP); ";
                    }
                    else if (args_[2] == "down")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND, " + args_[3] + ", (IntPtr)APPCOMMAND_VOLUME_DOWN); ";
                    }
                    else if (args_[2] == "mute")
                    {
                        return "SendMessageW(" + args_[3] + ", WM_APPCOMMAND, " + args_[3] + ", (IntPtr)APPCOMMAND_VOLUME_MUTE); ";
                    }
                }
                if (args_[1] == "keys")
                {
                    usingKeys = true;

                    if (args_[2] == "press_event")
                    {
                        return "gHook = new GlobalKeyboardHook(); " + Environment.NewLine +
                        "gHook.KeyDown += new KeyEventHandler(" + args_[3] + "); " + Environment.NewLine +
                        "foreach (Keys key in Enum.GetValues(typeof(Keys))) " + Environment.NewLine +
                            "gHook.HookedKeys.Add(key); " + Environment.NewLine;
                    }
                    else if (args_[2] == "hook" || args_[2] == "start")
                    {
                        return "gHook.hook();";
                    }
                    else if (args_[2] == "unhook" || args_[2] == "stop")
                    {
                        return "gHook.unhook();";
                    }
                }
            }
            else if (args_[0].Contains("}") || args_[0].Contains("{") || (args_[0].Contains(";")))
            {
                string all = " ";
                foreach (string s in args_)
                {
                    all += s + " ";
                }
                return all.Trim();
            }
            else if (args_[0].Contains("void") || args_[0].Contains("int"))
            {
                if (args_[1] == "Main()" || args_[1] == "main()")
                {
                    return "int main() {";
                }
            }

            if (args_[0] != string.Empty)
            {
                string all_ = " ";
                foreach (string s in args_)
                {
                    all_ += s + " ";
                }
                return all_.Trim() + ";";
            }

            return "";
        }



        static bool usingVoids = false;


        static bool usingWindow = false;
        static bool usingVolume = false;
        static bool usingKeys = false;
        static bool usingGraphics = false;
        static bool usingImap = false;
        static bool usingFile = false;


        static string ReplaceItems(string toReplce)
        {
            string Finished_Item = toReplce;



            if (toReplce.Contains("-ToChArarray") || toReplce.Contains("-ToChararray"))
            {
                Finished_Item = Finished_Item.Replace("-tochararray", ".ToCharArray()");
            }


            return Finished_Item;
        }


        static void Compile(string fileName, string toCompile)
        {
            File.WriteAllText(fileName + ".cpp", toCompile);
            Console.WriteLine(fileName + ".cpp -o " + fileName + ".exe");
            var p = new Process();
            p.StartInfo = new ProcessStartInfo(@"g++.exe", fileName + ".cpp -o " + fileName + ".exe")
            {
                UseShellExecute = false
            };

            p.Start();
            p.WaitForExit();
        }
    }
}
